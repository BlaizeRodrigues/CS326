package EVM;
import java.util.*;
import Value.*;

// All StackElements of reference type are instances of Object_ !!

public class Object_ {
    
    //
    // Most of the methods have been deleted - they are not needed now.
    //

    public String className() {
        return "";
    }    
}
