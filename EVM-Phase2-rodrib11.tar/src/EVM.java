import EVM.*;
import Utilities.*;
import Utilities.Error;
import Value.*;
import OperandStack.*;
import Instruction.*;
import java.util.*;
import java.io.*;

public class EVM {
    
    static private void binOp(int opcode, int type, OperandStack operandStack) {
	Value o1, o2;

        o1 = operandStack.pop();
        o2 = operandStack.pop();

        // Check that the operands have the right type
        if (!(o1.getType() == type && o2.getType() == type))
            Error.error("Error: Type mismatch - operands do not match operator.");

        switch (opcode) {
        case RuntimeConstants.opc_dadd: operandStack.push(new DoubleValue(((DoubleValue)o2).getValue() + ((DoubleValue)o1).getValue())); break;
        case RuntimeConstants.opc_dsub: operandStack.push(new DoubleValue(((DoubleValue)o2).getValue() - ((DoubleValue)o1).getValue())); break;
        case RuntimeConstants.opc_ddiv: operandStack.push(new DoubleValue(((DoubleValue)o2).getValue() / ((DoubleValue)o1).getValue())); break;
        case RuntimeConstants.opc_dmul: operandStack.push(new DoubleValue(((DoubleValue)o2).getValue() * ((DoubleValue)o1).getValue())); break;
        case RuntimeConstants.opc_drem: operandStack.push(new DoubleValue(((DoubleValue)o2).getValue() % ((DoubleValue)o1).getValue())); break;
	    
        case RuntimeConstants.opc_fadd: operandStack.push(new FloatValue(((FloatValue)o2).getValue() + ((FloatValue)o1).getValue())); break;
        case RuntimeConstants.opc_fsub: operandStack.push(new FloatValue(((FloatValue)o2).getValue() - ((FloatValue)o1).getValue())); break;
        case RuntimeConstants.opc_fdiv: operandStack.push(new FloatValue(((FloatValue)o2).getValue() / ((FloatValue)o1).getValue())); break;
        case RuntimeConstants.opc_fmul: operandStack.push(new FloatValue(((FloatValue)o2).getValue() * ((FloatValue)o1).getValue())); break;
        case RuntimeConstants.opc_frem: operandStack.push(new FloatValue(((FloatValue)o2).getValue() % ((FloatValue)o1).getValue())); break;

        case RuntimeConstants.opc_ladd: operandStack.push(new LongValue(((LongValue)o2).getValue() + ((LongValue)o1).getValue())); break;
        case RuntimeConstants.opc_lsub: operandStack.push(new LongValue(((LongValue)o2).getValue() - ((LongValue)o1).getValue())); break;
        case RuntimeConstants.opc_ldiv: operandStack.push(new LongValue(((LongValue)o2).getValue() / ((LongValue)o1).getValue())); break;
        case RuntimeConstants.opc_lmul: operandStack.push(new LongValue(((LongValue)o2).getValue() * ((LongValue)o1).getValue())); break;
        case RuntimeConstants.opc_lrem: operandStack.push(new LongValue(((LongValue)o2).getValue() % ((LongValue)o1).getValue())); break;

        case RuntimeConstants.opc_iadd: operandStack.push(new IntegerValue(((IntegerValue)o2).getValue() + ((IntegerValue)o1).getValue())); break;
        case RuntimeConstants.opc_isub: operandStack.push(new IntegerValue(((IntegerValue)o2).getValue() - ((IntegerValue)o1).getValue())); break;
        case RuntimeConstants.opc_idiv: operandStack.push(new IntegerValue(((IntegerValue)o2).getValue() / ((IntegerValue)o1).getValue())); break;
        case RuntimeConstants.opc_imul: operandStack.push(new IntegerValue(((IntegerValue)o2).getValue() * ((IntegerValue)o1).getValue())); break;
        case RuntimeConstants.opc_irem: operandStack.push(new IntegerValue(((IntegerValue)o2).getValue() % ((IntegerValue)o1).getValue())); break;


	}

    }
    
    static private void swap(OperandStack operandStack) {
	
        Value o1, o2;

        o1 = operandStack.pop();
        o2 = operandStack.pop();

       if ((o1 instanceof DoubleValue) || (o1 instanceof LongValue) ||
                (o2 instanceof DoubleValue) || (o2 instanceof LongValue)){
                Error.error("Error: Swap cannot be used on value of type Double or Long.");
                }else if (!(o1 instanceof DoubleValue) || (o1 instanceof LongValue) ||
                (o2 instanceof DoubleValue) || (o2 instanceof LongValue)) {

                    operandStack.push(o1);
                    operandStack.push(o2);
                }
        

    }
    
    static private void negate(int type, OperandStack operandStack) {
	Value o1,o2;

        o1 = operandStack.pop();

    if(o1.getType() == Value.s_integer){
    o2 = new IntegerValue(-1);
      operandStack.push(new IntegerValue(((IntegerValue)o2).getValue() * ((IntegerValue)o1).getValue()));
        }
    else if(o1 instanceof LongValue){
    o2 = new LongValue(-1);
      operandStack.push(new LongValue(((LongValue)o2).getValue() * ((LongValue)o1).getValue()));
        }
    else if(o1 instanceof FloatValue){
    o2 = new FloatValue(-1);
      operandStack.push(new FloatValue(((FloatValue)o2).getValue() * ((FloatValue)o1).getValue()));
        }
    else if(o1.getType() == Value.s_double){
    o2 = new DoubleValue(-1);
      operandStack.push(new DoubleValue(((DoubleValue)o2).getValue() * ((DoubleValue)o1).getValue()));
        }
        
       
    }
    
    static private void cmp(int type, OperandStack operandStack) {
	
	Value o1,o2;



    o1 = operandStack.pop();
    o2 = operandStack.pop();

    if (!(o1.getType() == type && o2.getType() == type)) {
    Error.error("Error: Type mismatch - operands do not match operator.");
    }
    
    if(o1.getType() == Value.s_integer){
Error.error("Error: Comparisons for Integers will be done in a later Phase");
    }
    
    if(o1 instanceof FloatValue) {


    if (((FloatValue)o1).getValue() > ((FloatValue)o2).getValue()) {
    
        operandStack.push(new IntegerValue(-1)); 
    }else if(((FloatValue)o1).getValue() < ((FloatValue)o2).getValue()) {
        
      operandStack.push(new IntegerValue(1));
        }else if(((FloatValue)o1).getValue() == ((FloatValue)o2).getValue()) {
       
      operandStack.push(new IntegerValue(0));
        }
}
    if(o1 instanceof LongValue) {
    
    if (((LongValue)o1).getValue() > ((LongValue)o2).getValue()) {
        operandStack.push(new IntegerValue(-1)); 
    }else if(((LongValue)o1).getValue() < ((LongValue)o2).getValue()) {
      operandStack.push(new IntegerValue(1));
        }else if(((LongValue)o1).getValue() == ((LongValue)o2).getValue()) {
      operandStack.push(new IntegerValue(0));
        }
    }
    
    if(o1.getType() == Value.s_double){
    if (((DoubleValue)o1).getValue() > ((DoubleValue)o2).getValue()) {
        operandStack.push(new IntegerValue(-1)); 
    }else if(((DoubleValue)o1).getValue() < ((DoubleValue)o2).getValue()) {
      operandStack.push(new IntegerValue(1));
        }else if(((DoubleValue)o1).getValue() == ((DoubleValue)o2).getValue()) {
      operandStack.push(new IntegerValue(0));
        }

        }

}


    static private void two(int from, int to, OperandStack operandStack) {
	
	Value e = operandStack.pop();
        if (e.getType() != from)
            Error.error("OperandStack.two: Type mismatch.");
	
        switch (from) {
        case Value.s_integer:
            int iv = ((IntegerValue)e).getValue();
            switch (to) {
            case Value.s_byte:   operandStack.push(new IntegerValue((int)((byte) iv))); break;
            case Value.s_char:   operandStack.push(new IntegerValue((int)((char) iv))); break;
            case Value.s_short:  operandStack.push(new IntegerValue((int)((short)iv))); break;
            case Value.s_double: operandStack.push(new DoubleValue((double)iv)); break;
		}

    }
    switch (from){
		case Value.s_float:
            float ix = ((FloatValue)e).getValue();
            switch (to) {
            case Value.s_integer: operandStack.push(new IntegerValue((int) ix)); break;
            case Value.s_long:   operandStack.push(new FloatValue((float)((long) ix))); break;
            case Value.s_double: operandStack.push(new DoubleValue((double)ix)); break;
	    }
    }
    switch (from){
        case Value.s_long:
            long iz = ((LongValue)e).getValue();
            switch (to) {
            case Value.s_integer:   operandStack.push(new LongValue((long)((int) iz))); break;
            case Value.s_float:   operandStack.push(new LongValue((long)((float) iz))); break;
            case Value.s_double: operandStack.push(new DoubleValue((double)iz)); break;
        }
    }
    switch (from){
        case Value.s_double:
            double iy = ((DoubleValue)e).getValue();
            switch (to) {
            case Value.s_integer:   operandStack.push(new DoubleValue((double)((int) iy))); break;
            case Value.s_float:   operandStack.push(new DoubleValue((double)((float) iy))); break;
            case Value.s_long: operandStack.push(new LongValue((long)iy)); break;
        }
    }
	   
    }
    
    
    static private void dup(int opCode, OperandStack operandStack) {
	// In real JVM a Double or a Long take up 2 stack words, but EVM Doubles and Longs
        // do not, so since dup2 can be used to either duplicate 2 single word values or
        // 1 double word value, we need to check the type of what is on the stack before
        // we decide if we should duplicate just one value or two.
        switch (opCode) {
        case RuntimeConstants.opc_dup:   operandStack.push(operandStack.peek(1)); break;
        case RuntimeConstants.opc_dup2: {
            Value o1 = operandStack.peek(1);
            Value o2;
            if ((o1 instanceof DoubleValue) || (o1 instanceof LongValue))
                operandStack.push(o1);
            else {
                o2 = operandStack.peek(2);
                operandStack.push(o2);
                operandStack.push(o1);
            }
        }
            break;
        case RuntimeConstants.opc_dup_x1: {
            Value o1 = operandStack.pop();
            Value o2 = operandStack.pop();
            if ((o1 instanceof DoubleValue) || (o1 instanceof LongValue) ||
                (o2 instanceof DoubleValue) || (o2 instanceof LongValue))
                Error.error("Error: dup_x1 cannot be used on value of type Double or Long.");
            operandStack.push(o1);
            operandStack.push(o2);
            operandStack.push(o1);
        }
            break;
        case RuntimeConstants.opc_dup_x2: {
            Value o1 = operandStack.pop();
            Value o2 = operandStack.pop();
            if ((o1 instanceof DoubleValue) || (o1 instanceof LongValue))
                Error.error("Error: dup_x2 cannot be used on value of type Double or Long.");
            if ((o2 instanceof DoubleValue) || (o2 instanceof LongValue)) {
                operandStack.push(o1);
                operandStack.push(o2);
                operandStack.push(o1);
            } else {
                Value o3 = operandStack.pop();
                if ((o3 instanceof DoubleValue) || (o3 instanceof LongValue))
                    Error.error("Error: word3 of dup_x2 cannot be  of type Double or Long.");
                operandStack.push(o1);
                operandStack.push(o3);
                operandStack.push(o2);
                operandStack.push(o1);
            }
        }
            break;
        case RuntimeConstants.opc_dup2_x1: {
            Value o1 = operandStack.pop();
            if ((o1 instanceof DoubleValue) || (o1 instanceof LongValue)) {
                Value o2 = operandStack.pop();
                if ((o2 instanceof DoubleValue) || (o2 instanceof LongValue))
                    Error.error("Error: word3 of dup2_x1 cannot be of type Double or Long.");
                operandStack.push(o1);
                operandStack.push(o2);
                operandStack.push(o1);
            } else {
                Value o2 = operandStack.pop();
                if ((o2 instanceof DoubleValue) || (o2 instanceof LongValue))
                    Error.error("Error: word2 of dup2_x1 cannot be of type Double or Long when word1 is not.");
                Value o3 = operandStack.pop();
                if ((o3 instanceof DoubleValue) || (o3 instanceof LongValue))
                    Error.error("Error: word3 of dup2_x1 cannot be of type Double or Long.");
                operandStack.push(o2);
                operandStack.push(o1);
                operandStack.push(o3);
                operandStack.push(o2);
                operandStack.push(o1);
            }
        }
            break;
        case RuntimeConstants.opc_dup2_x2: {
            Value o1 = operandStack.pop();
            if ((o1 instanceof DoubleValue) || (o1 instanceof LongValue)) {
                Value o2 = operandStack.pop();
                if (!((o2 instanceof DoubleValue) || (o2 instanceof LongValue)))
                    Error.error("Error: word3 of dup2_x2 must be of type Double or Long.");
                operandStack.push(o1);
                operandStack.push(o2);
                operandStack.push(o1);
            } else {
                Value o2 = operandStack.pop();
                if ((o2 instanceof DoubleValue) || (o2 instanceof LongValue))
                    Error.error("Error: word2 of dup2_x2 cannot be of type Double or Long when word1 is not.");
                Value o3 = operandStack.pop();
                if (!((o3 instanceof DoubleValue) || (o3 instanceof LongValue)))
                    Error.error("Error: word3/4 of dup2_x2 must be of type Double or Long.");
                operandStack.push(o2);
                operandStack.push(o1);
                operandStack.push(o3);
                operandStack.push(o2);
                operandStack.push(o1);
            }
        }
            break;
        }
    }
    
    
    static private void logic(int inst, OperandStack operandStack) {
        Value o1, o2;
    

        o1 = operandStack.pop();
        o2 = operandStack.pop();

        switch(inst){

            case RuntimeConstants.opc_iand:{
             
                operandStack.push(new IntegerValue (((IntegerValue)o1).getValue() & ((IntegerValue)o2).getValue()));
            }
            break;
            case RuntimeConstants.opc_ior:{
             
                operandStack.push(new IntegerValue (((IntegerValue)o1).getValue() | ((IntegerValue)o2).getValue()));
            }
            break;
            case RuntimeConstants.opc_ixor:{
             
                operandStack.push(new IntegerValue (((IntegerValue)o1).getValue() ^ ((IntegerValue)o2).getValue()));
            }
            break;
            case RuntimeConstants.opc_land:{
             
                operandStack.push(new LongValue (((LongValue)o1).getValue() & ((LongValue)o2).getValue()));
            }
            break;
            case RuntimeConstants.opc_lor:{
             
                operandStack.push(new LongValue (((LongValue)o1).getValue() | ((LongValue)o2).getValue()));
            }
            break;
            case RuntimeConstants.opc_lxor:{
             
                operandStack.push(new LongValue (((LongValue)o1).getValue() ^ ((LongValue)o2).getValue()));
            }
            break;

        }
	
    }
    
    static private void shift(int opCode, OperandStack operandStack) {
	
	Value o1, o2;

        o1 = operandStack.pop();
        o2 = operandStack.pop();

        // Check that the operands have the right type
       if ((o1 instanceof IntegerValue) && (o2 instanceof LongValue) || (o2 instanceof IntegerValue) && (o1 instanceof LongValue) ){
                Error.error("Error: Type mismatch - operands do not match operator.");
}
        if ((o1 instanceof DoubleValue) || (o1 instanceof FloatValue) ||
                (o2 instanceof DoubleValue) || (o2 instanceof FloatValue)){
                Error.error("Error: Shift cannot be used on value of type Double or Float.");
}
        switch (opCode) {
        case RuntimeConstants.opc_ishl: operandStack.push(new IntegerValue(((IntegerValue)o2).getValue() << (31 & ((IntegerValue)o1).getValue()))); break;
        case RuntimeConstants.opc_ishr: operandStack.push(new IntegerValue(((IntegerValue)o2).getValue() >> (31 & ((IntegerValue)o1).getValue()))); break;
        case RuntimeConstants.opc_iushr: operandStack.push(new IntegerValue(((IntegerValue)o2).getValue()>>> (31 & ((IntegerValue)o1).getValue()))); break;
        case RuntimeConstants.opc_lshl: operandStack.push(new LongValue(((LongValue)o2).getValue() << (63 & ((LongValue)o1).getValue()))); break;
        case RuntimeConstants.opc_lshr: operandStack.push(new LongValue(((LongValue)o2).getValue() >> (63 & ((LongValue)o1).getValue()))); break;
        case RuntimeConstants.opc_lushr: operandStack.push(new LongValue(((LongValue)o2).getValue()>>> (63 & ((LongValue)o1).getValue()))); break;
        
    }

}

    



    public static void main(String argv[]) {
	OperandStack operandStack = new OperandStack(100, "Phase 2");
	Value v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12;
	
	operandStack.push(new IntegerValue(100));

	v1 = Value.makeValue((double)5);
	v2 = new DoubleValue(100);
    v3 = new DoubleValue (2.5);
    v4 = new DoubleValue (31);
    v5 = new DoubleValue (11.0);
    v6 = new DoubleValue (10.0);
    
    operandStack.push(v1);
    operandStack.push(v2);
    operandStack.push(v3);
    operandStack.push(v4);
    operandStack.push(v5);
    operandStack.push(v6);


    System.out.println("+------PHASE 2-------+\n");

    System.out.println(operandStack);

//binOp Test Case
    System.out.println("---opCode Test Cases---\n");
    System.out.println("---opCodes for Double Values---");
    System.out.println("---opCode dadd---");
	binOp(RuntimeConstants.opc_dadd, Value.s_double, operandStack);
    System.out.println(operandStack); // 21.0
System.out.println("---opCode dsub---");
    binOp(RuntimeConstants.opc_dsub, Value.s_double, operandStack);
    System.out.println(operandStack); //10.0
System.out.println("---opCode dmul---");
    binOp(RuntimeConstants.opc_dmul, Value.s_double, operandStack);
    System.out.println(operandStack); //25.0
System.out.println("---opCode ddiv---");
    binOp(RuntimeConstants.opc_ddiv, Value.s_double, operandStack);
    System.out.println(operandStack); //4.0
System.out.println("---opCode drem---");
    binOp(RuntimeConstants.opc_drem, Value.s_double, operandStack);
    System.out.println(operandStack); //1.0
    operandStack.pop(); // Stack size = 1

System.out.println("\n---Doubles are Complete---\n");

System.out.println(operandStack);

System.out.println("\n---opCodes for Float Values---\n");
v1 = Value.makeValue((float)5);
    v2 = Value.makeValue((float)100);
    v3 = Value.makeValue((float)2.5);
    v4 = Value.makeValue((float)31);
    v5 = Value.makeValue((float)11.0);
    v6 = Value.makeValue((float)10.0);
    
    operandStack.push(v1);
    operandStack.push(v2);
    operandStack.push(v3);
    operandStack.push(v4);
    operandStack.push(v5);
    operandStack.push(v6);



    System.out.println(operandStack);

System.out.println("---opCode fadd---");
    binOp(RuntimeConstants.opc_fadd, Value.s_float, operandStack);
    System.out.println(operandStack); //21.0
System.out.println("---opCode fsub---");
    binOp(RuntimeConstants.opc_fsub, Value.s_float, operandStack);
    System.out.println(operandStack);//10.0
System.out.println("---opCode fmul---");
    binOp(RuntimeConstants.opc_fmul, Value.s_float, operandStack);
    System.out.println(operandStack);//25.0
System.out.println("---opCode fdiv---");
    binOp(RuntimeConstants.opc_fdiv, Value.s_float, operandStack);
    System.out.println(operandStack); //4.0
System.out.println("---opCode frem---");
    binOp(RuntimeConstants.opc_frem, Value.s_float, operandStack);
    System.out.println(operandStack); //1.0

operandStack.pop();

System.out.println("\n---Floats are Complete---\n");
System.out.println(operandStack);



System.out.println("\n---opCodes for Long Values---");
v1 = Value.makeValue((long)5000);
    v2 = Value.makeValue((long)100000);
    v3 = Value.makeValue((long)250);
    v4 = Value.makeValue((long)310);
    v5 = Value.makeValue((long)110);
    v6 = Value.makeValue((long)100);
    
    operandStack.push(v1);
    operandStack.push(v2);
    operandStack.push(v3);
    operandStack.push(v4);
    operandStack.push(v5);
    operandStack.push(v6);

    System.out.println(operandStack);
System.out.println("---opCode ladd---");
    binOp(RuntimeConstants.opc_ladd, Value.s_long, operandStack);
    System.out.println(operandStack);//210
System.out.println("---opCode lsub---");
    binOp(RuntimeConstants.opc_lsub, Value.s_long, operandStack);
    System.out.println(operandStack);//100
System.out.println("---opCode lmul---");
    binOp(RuntimeConstants.opc_lmul, Value.s_long, operandStack);
    System.out.println(operandStack);//25000
System.out.println("---opCode ldiv---");
    binOp(RuntimeConstants.opc_ldiv, Value.s_long, operandStack);
    System.out.println(operandStack);//4
System.out.println("---opCode lrem---");
    binOp(RuntimeConstants.opc_lrem, Value.s_long, operandStack);
    System.out.println(operandStack);//0

    operandStack.pop();

System.out.println("\n---Longs are Complete---\n");

System.out.println(operandStack);



System.out.println("\n---opCodes for Integer Values---");
v1 = Value.makeValue((int)50);
    v2 = Value.makeValue((int)1000);
    v3 = Value.makeValue((int)25);
    v4 = Value.makeValue((int)31);
    v5 = Value.makeValue((int)11);
    v6 = Value.makeValue((int)10);
    
    operandStack.push(v1);
    operandStack.push(v2);
    operandStack.push(v3);
    operandStack.push(v4);
    operandStack.push(v5);
    operandStack.push(v6);

    System.out.println(operandStack);
System.out.println("---opCode iadd---");
    binOp(RuntimeConstants.opc_iadd, Value.s_integer, operandStack);
    System.out.println(operandStack);
System.out.println("---opCode isub---");
    binOp(RuntimeConstants.opc_isub, Value.s_integer, operandStack);
    System.out.println(operandStack);
System.out.println("---opCode imul---");
    binOp(RuntimeConstants.opc_imul, Value.s_integer, operandStack);
    System.out.println(operandStack);
System.out.println("---opCode idiv---");
    binOp(RuntimeConstants.opc_idiv, Value.s_integer, operandStack);
    System.out.println(operandStack);
System.out.println("---opCode irem---");
    binOp(RuntimeConstants.opc_irem, Value.s_integer, operandStack);
    System.out.println(operandStack);
    operandStack.pop();

System.out.println("\n---Integers are Complete---\n");

System.out.println(operandStack);


System.out.println("\n---opCode Test Cases Complete---\n");

System.out.println("-------------\n");


//swap test cases
System.out.println("-------Test Cases for Swap------\n");
    v1 = Value.makeValue((int)5);
    v2 = Value.makeValue((int)10);
    v3 = Value.makeValue((float)2.5);
    v4 = Value.makeValue((float)4.5);
    operandStack.push(v1);
    operandStack.push(v2);
    operandStack.push(v3);
    operandStack.push(v4);

    System.out.println(operandStack);
    System.out.println("\nSwapping Float Values...\n");

     swap(operandStack); 
System.out.println(operandStack);
  System.out.println("\nRemoving Float Values to test Integer values...\n");
     operandStack.pop();
     operandStack.pop();
System.out.println(operandStack);
System.out.println("\nSwapping Integer Values...\n");
     swap(operandStack);

     System.out.println(operandStack);

System.out.println("\nRemoving Integer values...\n");
     operandStack.pop();
     operandStack.pop();

System.out.println(operandStack);

System.out.println("\n---Swap Test Cases Complete---\n");

System.out.println("-------------\n");

//negate test cases

System.out.println("-------Test Cases for Negate------\n");
v1 = Value.makeValue((int)5);
    v2 = Value.makeValue((long)10000);
    v3 = Value.makeValue((float)2.5);
    v4 = Value.makeValue((double)4.5);
    operandStack.push(v1);
    operandStack.push(v2);
    operandStack.push(v3);
    operandStack.push(v4);

    System.out.println(operandStack);

    negate(Value.s_double, operandStack);
    System.out.println("\nNegating Double value...\n");
    System.out.println(operandStack);
    operandStack.pop();
    System.out.println("\nRemoving Negative Double value to test Float...\n");
    
    System.out.println(operandStack);
    negate(Value.s_float, operandStack);
    System.out.println("\nNegating Float value...\n");
    System.out.println(operandStack);
    operandStack.pop();
    System.out.println("\nRemoving Negative Float value to test Long...\n");
    
    System.out.println(operandStack);
    negate(Value.s_long, operandStack);
    System.out.println("\nNegating Long value...\n");
    System.out.println(operandStack);
    operandStack.pop();
    System.out.println("\nRemoving Negative Long value to test int...\n");
    
    System.out.println(operandStack);
    negate(Value.s_integer, operandStack);
    System.out.println("\nNegating Integer value...\n");
    System.out.println(operandStack);
    operandStack.pop();
    System.out.println("\nRemoving Negative Integer value...\n");
     System.out.println(operandStack);
    
    System.out.println("\n---NegateTest Cases Complete---\n");

System.out.println("-------------\n");

//cmp test cases
System.out.println("-------Test Cases for cmp------\n");

    v1 = Value.makeValue((double)6.89);
    v2 = Value.makeValue((double)10.98);
    v3 = Value.makeValue((float)12.65);
    v4 = Value.makeValue((float)12.65);
    v5 = Value.makeValue((long)2500);
    v6 = Value.makeValue((long)1000);
    
    operandStack.push(v1);
    operandStack.push(v2);
    operandStack.push(v3);
    operandStack.push(v4);
    operandStack.push(v5);
    operandStack.push(v6);

    System.out.println(operandStack);

System.out.println("\nComparing long values...\n");
    cmp(Value.s_long,operandStack);
    System.out.println(operandStack);

    System.out.println("\nRemoving top value from the stack to test Float cmp...\n");
    operandStack.pop();
     System.out.println(operandStack);

System.out.println("\nComparing Float values...\n");
    cmp(Value.s_float,operandStack);
    System.out.println(operandStack);

System.out.println("\nRemoving top value from the stack to test Double cmp...\n");
    operandStack.pop();
     System.out.println(operandStack);

System.out.println("\nComparing Double value...\n");
    cmp(Value.s_double,operandStack);
    System.out.println(operandStack);
    operandStack.pop();

System.out.println("\nRemoving top value from the stack...\n");

 System.out.println(operandStack);
System.out.println("\n---cmp Test Cases Complete---\n");

System.out.println("-------------\n");


//two test cases
System.out.println("-------Test Cases for two------\n");
    v1 = Value.makeValue((float)10.98);
    v2 = Value.makeValue((double)12.65);
    v3 = Value.makeValue((long)120);
    operandStack.push(v1);
    operandStack.push(v2);
    operandStack.push(v3);
    System.out.println(operandStack);
   
System.out.println("\nConverting long Value to an Integer Value...\n");
    two(Value.s_long,Value.s_integer,operandStack);
    System.out.println(operandStack);

System.out.println("\nRemoving top value from the stack...\n");
    operandStack.pop();
    System.out.println(operandStack);

System.out.println("\nConverting Double Value to a Float Value...\n");
    two(Value.s_double,Value.s_float,operandStack);
    System.out.println(operandStack);

    System.out.println("\nRemoving top value from the stack...\n");
    operandStack.pop();
    System.out.println(operandStack);

    System.out.println("\nConverting the Float Value to an Integer Value...\n");
    two(Value.s_float,Value.s_integer,operandStack);
    System.out.println(operandStack);

System.out.println("\nConverting the Integer Value to a Double Value...\n");
    two(Value.s_integer,Value.s_double,operandStack);
    System.out.println(operandStack);
System.out.println("\nRemoving top value from the stack...\n");
    operandStack.pop();
    System.out.println(operandStack);
System.out.println("\n---two Test Cases Complete---\n");

System.out.println("-------------\n");

//logic test cases
System.out.println("-------Test Cases for Logic------\n");
    v1 = Value.makeValue((long)126);
    v2 = Value.makeValue((long)129);
    v3 = Value.makeValue((long)1265);
    v4 = Value.makeValue((long)1265);
    v5 = Value.makeValue((long)689);
    v6 = Value.makeValue((long)1098);
    v7 = Value.makeValue((int)12);
    v8 = Value.makeValue((int)65);
    v9 = Value.makeValue((int)89);
    v10 = Value.makeValue((int)10);
    v11 = Value.makeValue((int)13);
    v12= Value.makeValue((int)8);

    
    operandStack.push(v1);
    operandStack.push(v2);
    operandStack.push(v3);
    operandStack.push(v4);
    operandStack.push(v5);
    operandStack.push(v6);
    operandStack.push(v7);
    operandStack.push(v8);
    operandStack.push(v9);
    operandStack.push(v10);
    operandStack.push(v11);
    operandStack.push(v12);


    System.out.println(operandStack);
System.out.println("\nTesting Case for iand...\n");
    logic(RuntimeConstants.opc_iand, operandStack);
    System.out.println(operandStack);
System.out.println("\nRemoving top value from the stack...\n");
    operandStack.pop();
    System.out.println(operandStack);

    logic(RuntimeConstants.opc_ior, operandStack);
    System.out.println("\nTesting Case for ior...\n");
    System.out.println(operandStack);
    System.out.println("\nRemoving top value from the stack...\n");
    operandStack.pop();
    System.out.println(operandStack);

    logic(RuntimeConstants.opc_ixor, operandStack);
    System.out.println("\nTesting Case for ixor...\n");
    System.out.println(operandStack);
    System.out.println("\nRemoving top value from the stack...\n");
    operandStack.pop();
    System.out.println(operandStack);

    logic(RuntimeConstants.opc_land, operandStack);
    System.out.println("\nTesting Case for land...\n");
    System.out.println(operandStack);
    System.out.println("\nRemoving top value from the stack...\n");
    operandStack.pop();
    System.out.println(operandStack);

    logic(RuntimeConstants.opc_lor, operandStack);
    System.out.println("\nTesting Case for lor...\n");
    System.out.println(operandStack);
    System.out.println("\nRemoving top value from the stack...\n");
    operandStack.pop();
    System.out.println(operandStack);

    logic(RuntimeConstants.opc_lxor, operandStack);
    System.out.println("\nTesting Case for lxor...\n");
    System.out.println(operandStack);
    System.out.println("\nRemoving top value from the stack...\n");
    operandStack.pop();
    System.out.println(operandStack);
System.out.println("\n---two Test Cases Complete---\n");

//shift test cases
System.out.println("---Shift Test Cases---");
v1 = Value.makeValue((long)126);
    v2 = Value.makeValue((long)129);
    v3 = Value.makeValue((long)1265);
    v4 = Value.makeValue((long)1265);
    v5 = Value.makeValue((long)689);
    v6 = Value.makeValue((long)1098);
    v7 = Value.makeValue((int)12);
    v8 = Value.makeValue((int)65);
    v9 = Value.makeValue((int)89);
    v10 = Value.makeValue((int)10);
    v11 = Value.makeValue((int)13);
    v12= Value.makeValue((int)8);

    
    operandStack.push(v1);
    operandStack.push(v2);
    operandStack.push(v3);
    operandStack.push(v4);
    operandStack.push(v5);
    operandStack.push(v6);
    operandStack.push(v7);
    operandStack.push(v8);
    operandStack.push(v9);
    operandStack.push(v10);
    operandStack.push(v11);
    operandStack.push(v12);


    System.out.println(operandStack);

System.out.println("\nTesting Case for ishr...\n");

    shift(RuntimeConstants.opc_ishr, operandStack);
    System.out.println(operandStack.pop()); 

 System.out.println(operandStack);
System.out.println("\nTesting Case for ishl...\n");

    shift(RuntimeConstants.opc_ishl, operandStack);
    System.out.println(operandStack.pop()); 

 System.out.println(operandStack);
System.out.println("\nTesting Case for iushr...\n");

    shift(RuntimeConstants.opc_iushr, operandStack);
    System.out.println(operandStack.pop()); 

 System.out.println(operandStack);
System.out.println("\nTesting Case for lshr...\n");

    shift(RuntimeConstants.opc_lshr, operandStack);
    System.out.println(operandStack.pop()); 

 System.out.println(operandStack);
System.out.println("\nTesting Case for lshl...\n");

    shift(RuntimeConstants.opc_lshl, operandStack);
    System.out.println(operandStack.pop()); 

 System.out.println(operandStack);
System.out.println("\nTesting Case for lushr...\n");

    shift(RuntimeConstants.opc_lushr, operandStack);
    System.out.println(operandStack.pop()); 

    System.out.println("\n---Shift Test Cases Complete---\n");

    System.out.println("-------------");

    System.out.println(operandStack);

    }
}
