/* Blaize K. Rodrigues*/
package OperandStack;
import Value.*;
import java.io.*;
import Utilities.Error;
/**
 * A stack for doing arithmetic and logic operations. Stack elements are of type {@link Value}.
 * @author   Matt B. Pedersen
 * @version  1.0
*/
public class OperandStack {

    /**
     * The size of the operand stack. We could have made this dynamic, but as long as we choose a number
     * large enough it should be fine with a fixed sized stack
     */
    private int stackSize;
    /** 
     * The internal stack holding the actual values. These values are of type {@link Value}.
     */
    // Hint, if you don't make it an array the toString() method wont work as it is ;-)
    public Value stack[] = new Value [1000];
    /**
     * The stack pointer. The stack pointer always points to the next free location in the <a href="#stack">stack<a> array.
     */
    public int sp;
    /**
     * Just a name to give to the stack - helps with debugging later.
     */
    private String name;
    /**
     * We keep track of the numbers of stacks created - just for statistics later.
     */
    private static int stackNo =0;
    public int stackNumber;

    /**
     * Creates a new operand stack of size <b>size</b> and sets the stack pointer to 0.
     * @param size The size of the newly created operand stack.
     * @see #stack
     * @see #sp 
     */
    public OperandStack(int size, String name) {
    this.name = name;
    stackNumber = stackNo;
    stackNo++;
    stackSize = size;
    sp = 0;
    System.out.println('\n');
    System.out.println('|' + name + '|');
    }

    /**
     * Pushes one element of type {@link Value} on to the operand stack and increments the stack pointer (sp) by one.
     * <p>
     * stack before push: .... X<br>
     * push(Y);<br>
     * stack after push:  .... X Y
     * <p>
     * An error is signaled if no more room is available on the stack.
     * @param e An object of the {@link Value} type to be placed on the stack.
     */
    public void push(Value e) {
    if(sp < stackSize ) //If the stack is not full, push a value onto the stack
        {

            stack[sp] = e;  //adds e to the top of the stack
             sp++;
        
    }
    else{
        System.out.println("Stack Overlow"); //if the sack is full, the error message is presented
        System.exit(1);
    }

}
    /**
     * Pops one element of type {@link Value} off the operand stack and decrements the stack pointer (sp) by one.
     * <p>
     * stack before pop: .... X Y<br>
     * Z = pop();<br>
     * stack after pop:  .... X<br>
     * and Z = Y
     * <p>
     * An error is signaled if the stack is empty.
     * @return Returns an object of type {@link Value}.
     */
    public Value pop() {
   if(sp != 0){ //if the stack is not empty, the top value of the stack is removed
        sp--; //decrement the stack pointer by 1
        return stack[sp]; //removes the top value on the stack

   }else{
    
    System.out.println("There is nothing in the stack"); //if the stack is empty then an error messgage is presented
    System.out.println('\n');
    System.exit(1);

    return null;
   }
    }
    
    /** 
     * Returns the n'th element on the stack (counted from the top)
     * without removing it.
     *
     * @param n The index (counting from the top of the stack) of the 
     * element to be returned. The top element is at index 1.
     */
    public Value peek(int n) {
    if(stackSize != 0) // if the stack is not empty, the top element from the stack is presented without being removed
    {
        return stack[sp-n]; 
    }
    else{
        return null;
    }
    }
        
    /**
     * Prints out the operand stack with information about every elements type.
     */
    public void dump(PrintWriter out) {
    out.println(toString());
    }

    public String toString() {
    String s = "";
    s = "| Operand Stack " + stackNumber + " - "+ name + " (size = "+sp+") --------------- \n| ";
        for (int i=0;i<sp;i++) {
            if (stack[i] == null)
                s = s + "null ";
            else
                s = s + stack[i] + "{" + stack[i].type2String()+ "} ";
        }
    s = s + "\n+----------------------------------------------------------------";
    return s;
    }


    public void dump_(PrintWriter out) {
    int max = 20;
    // compute the max width of any element
    for (int i=0;i<sp;i++) {
        if (stack[i] == null)
        max = 6 > max ? 6 : max; // ' null '
        else {
        int l;
        l  = (stack[i] + " {" + stack[i].type2String()+ "}").length();
        max = l > max ? l : max;
        }   
    }
    
    int left, right, spcs;

    for (int i=0;i<sp;i++) {
        if (stack[sp-i-1] == null) {
        spcs = max - 6;
        left = spcs/2;
        right = spcs - left;
        out.println("|" + spaces(left) + " null " + spaces(right) + "|");
        } else {
        String st = "" + stack[sp-i-1] + " {" + stack[sp-i-1].type2String()+ "}";
        spcs = max - st.length();
        left = spcs / 2;
        right = spcs - left;
        out.println("|" + spaces(left) + st + spaces(right) + "|");
        }
    }
    }
    
    private String spaces(int n) {
    String s = "";
    for (int i =0; i<n; i++) 
        s += " ";
    return s;
    }


}

        
