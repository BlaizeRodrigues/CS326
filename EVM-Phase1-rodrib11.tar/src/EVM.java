/* Blaize K. Rodrigues*/
import java.util.*;
import Utilities.Error;
import OperandStack.*;
import Value.*;
public class EVM {
  public static void main(String argv[]) {

      // This is a small example of how to use the stack
      
    /*  OperandStack operandStack = new OperandStack(100, "OperandStack Test");

      operandStack.push(new IntegerValue(100));
      operandStack.push(Value.makeDefaultValueFromSignature("Z"));
      operandStack.push(Value.makeValue("Hello"));

      System.out.println(operandStack.peek(1));
      System.out.println(operandStack.peek(2));
        
      // if we have an expression line 1 + 2 we can translate that into postfix 
      // like this: 1 2 +
      // so it becomes: push(1), push (2), pop() twice and add and push the result.
      operandStack.push(new IntegerValue(1));
      operandStack.push(new IntegerValue(2));
      Value v1, v2;
      v2 = operandStack.pop();
      v1 = operandStack.pop();
      // Note, since the stack holds 'Value' values we have to cast the 
      // values popped to the right kind.
      IntegerValue v3, v4;
      v4 = (IntegerValue)v2;
      v3 = (IntegerValue)v1;
      
      operandStack.push(new IntegerValue(v3.getValue() + v4.getValue()));
      System.out.println(operandStack.pop()); // ===> 11
      System.out.println(operandStack.pop()); // ===> Hello
      System.out.println(operandStack.pop()); // ===> true
      System.out.println(operandStack.pop()); // ===> 100
      System.out.println(operandStack.pop()); // ===> Error message & program termination
      System.out.println("This line should never be printed out");

      // Remove the code above and replace it by your own tests from the assignment
      */

      OperandStack operandStack = new OperandStack(100, "Blaize's OperandStack Test");
      System.out.println("The Current Stack is empty so we will add 2 to it");
      operandStack.push(new IntegerValue(2));
      System.out.println("Here is the Current Stack: ");
      System.out.println(operandStack.peek(1)); 
      System.out.println('\n');
      System.out.println("Adding 32 to the Stack...");
      operandStack.push(new IntegerValue(32));
      System.out.println("Here is the Current Stack: ");
      System.out.println(operandStack.peek(1)); 
      System.out.println(operandStack.peek(2));
      System.out.println('\n');
      System.out.println("Adding 54 to the Stack...");
      operandStack.push(new IntegerValue(54));
      System.out.println("Here is the Current Stack: ");
      System.out.println(operandStack.peek(1));
      System.out.println(operandStack.peek(2));
      System.out.println(operandStack.peek(3));
      System.out.println('\n');
      System.out.println("Adding 7 to the Stack");
      operandStack.push(new IntegerValue(7));
      System.out.println("Here is the Current Stack: ");
      System.out.println(operandStack.peek(1));
      System.out.println(operandStack.peek(2));
      System.out.println(operandStack.peek(3));
      System.out.println(operandStack.peek(4));
      System.out.println('\n');
      System.out.println("Adding 32 to the Stack...");
      operandStack.push(new IntegerValue(32));
      System.out.println("Here is the Current Stack: ");
      System.out.println(operandStack.peek(1));
      System.out.println(operandStack.peek(2));
      System.out.println(operandStack.peek(3));
      System.out.println(operandStack.peek(4));
      System.out.println(operandStack.peek(5));
      System.out.println('\n');
/*
      System.out.println(operandStack.peek(1));
      System.out.println(operandStack.peek(2));
      System.out.println(operandStack.peek(3));
      System.out.println(operandStack.peek(4));
      System.out.println(operandStack.peek(5));
*/
      Value n1, n2, n3, n4, n5;
      IntegerValue v1, v2, v3, v4, v5, s1, m1, a1;
      System.out.println("Popping 32 and 7 from the Stack...");
      n1 = operandStack.pop(); //pops 32 from the stack
      n2 = operandStack.pop(); //pops 7 from the stack
      v1 = (IntegerValue)n1; //converts n1 to an integer 
      v2 = (IntegerValue)n2; //same as above excpet for n2

      s1 = new IntegerValue(v1.getValue() - v2.getValue()); //s1 is the result of the first operand
      
      System.out.println("The result of 32 - 7 is: ");
      System.out.println(s1);
      System.out.println("Here is the Current Stack: ");
      System.out.println(operandStack.peek(1));
      System.out.println(operandStack.peek(2));
      System.out.println(operandStack.peek(3));
      System.out.println('\n');

      
      System.out.println("Popping 54 and 32 from the Stack...");
      n3 = operandStack.pop(); //pops 54 from the stack
      n4 = operandStack.pop(); //pops 32 from the stack
      v3 = (IntegerValue)n3;
      v4 = (IntegerValue)n4;


      a1 = new IntegerValue(v3.getValue() + v4.getValue());
      System.out.println("The result of 54 + 32 is: ");
      System.out.println(a1);

      System.out.println("Here is the Current Stack: ");
      System.out.println(operandStack.peek(1));
     
      System.out.println('\n');
      
      m1 = new IntegerValue(s1.getValue() * a1.getValue());
      System.out.println("The result of 32 - 7 x (54 + 32) is: ");
      System.out.println(m1);

      System.out.println('\n');

      System.out.println("Popping 2 from the Stack...");
      n5 = operandStack.pop();
      v5 = (IntegerValue)n5;
      operandStack.push(new IntegerValue(m1.getValue() / v5.getValue()));
      System.out.println("The result of 32 - 7 x (54 + 32) / 2 is: ");
      System.out.println(operandStack.peek(1));

      System.out.println('\n');



  }

}
